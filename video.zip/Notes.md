# PARA COMEÇAR PELO ZIP

unzip video.zip


* PARA ACESSAR A PASTA DO BOT

cd PastaDoBot (PastaDoBot = Nome da pasta do seu bot)


# TENHA CERTEZA QUE ACESSOU A PASTA DO BOT

* COMANDOS PARA O BOT FUNCIONAR

yarn install


+  DEPOIS DO COMANDO ACIMA FAZ O DEBAIXO  +

npm install


# TENHA CERTEZA DE EXECUTAR OS COMANDOS SEMPRE NA PASTA DO BOT 

* PARA INICIAR O BOT

npm start

# PARA FAZER PELO MODO ONLINE

wget https://github.com/alizin-dev/replit-ofc/raw/main/config.sh

* DEPOIS EXECUTAR NO CONSOLE 

sh config.sh


# ESTE PASSO SÓ DEVERÁ SER FEITO DEPOIS DE SCANEAR O QR CODE

+  EDITAR O CONTEÚDO DO ARQUIVO Main.sh  +

ONDE ESTÁ ESCRITO "PASTA" COLOCAR O NOME DA PASTADOBOT


*  LINHA PRA COLAR NA INDEX DO BOT (UPTIMEROBOT)


require("http").createServer((_, res) => res.end("FUNCIONANDO!")).listen(8080)



# FÉ TROPAA, FÉ EM DEUS, COPIO!
# MEU CHAT: https://chat.whatsapp.com/GcI1l0sflb2BMM199DmxOf
# MEU ZAP ( NÚMERO ): http://wa.me/5521989701174